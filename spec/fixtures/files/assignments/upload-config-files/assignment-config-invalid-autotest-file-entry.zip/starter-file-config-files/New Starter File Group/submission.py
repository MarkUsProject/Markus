def return_true():
    return True


def return_false():
    return False


def loop():
    while True:
        pass


def return_json():
    return ']}[{"\\'
